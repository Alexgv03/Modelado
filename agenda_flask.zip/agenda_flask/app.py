import json
import os
import uuid  # genera IDs únicos
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Define la ruta a nuestro archivo JSON
JSON_FILE = 'tareas.json'

#  Funciones del Modelo
def cargar_tareas():
    """Carga las tareas desde el archivo JSON."""
    if not os.path.exists(JSON_FILE):
        return []
    try:
        with open(JSON_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (IOError, json.JSONDecodeError):
        return []

def guardar_tareas(tareas):
    """Guarda la lista de tareas en el archivo JSON."""
    try:
        with open(JSON_FILE, 'w', encoding='utf-8') as f:
            json.dump(tareas, f, indent=4)
    except IOError as e:
        print(f"Error al guardar tareas: {e}")

#  Rutas de la app

@app.route('/')
def index():
    """
    Ruta principal: Muestra la lista de tareas
    """
    tareas = cargar_tareas()
    # Separa las tareas en pendientes y completadas
    pendientes = sorted([t for t in tareas if not t['completada']], key=lambda x: x['titulo'])
    completadas = sorted([t for t in tareas if t['completada']], key=lambda x: x['titulo'])
    return render_template('index.html', pendientes=pendientes, completadas=completadas)

@app.route('/agregar', methods=['POST'])
def agregar_tarea():
    """
    Ruta para agregar una nueva tarea. Se activa cuando se envía el formulario
    """
    # Obtiene el título del formulario
    titulo = request.form.get('titulo')
    
    if titulo: # Solo agrega si el titulo no esta vacio
        tareas = cargar_tareas()
        # Crea la nueva tarea
        nueva_tarea = {
            'id': str(uuid.uuid4()), # Genera un id unico
            'titulo': titulo,
            'completada': False
        }
        tareas.append(nueva_tarea)
        guardar_tareas(tareas)
        
    # Redirige de vuelta a la pagina principal
    return redirect(url_for('index'))

@app.route('/completar/<string:id_tarea>')
def completar_tarea(id_tarea):
    """
    Ruta para marcar una tarea como completa (o incompleta)
    """
    tareas = cargar_tareas()
    for tarea in tareas:
        if tarea['id'] == id_tarea:
            # Invierte el estado de "completada"
            tarea['completada'] = not tarea['completada']
            break
    guardar_tareas(tareas)
    return redirect(url_for('index'))

@app.route('/eliminar/<string:id_tarea>')
def eliminar_tarea(id_tarea):
    """
    Ruta para eliminar una tarea.
    """
    tareas = cargar_tareas()
    # Filtra la lista excluyendo la tarea con el id a eliminar
    tareas = [t for t in tareas if t['id'] != id_tarea]
    guardar_tareas(tareas)
    return redirect(url_for('index'))


if __name__ == '__main__':
    # Ejecuta la aplicacion en modo de depuracion
    app.run(debug=True, port=5000)
